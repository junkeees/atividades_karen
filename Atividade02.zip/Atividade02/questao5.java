package hola;

public class Q05 {

	public static void main(String[] args) {
		
		

	}

}
